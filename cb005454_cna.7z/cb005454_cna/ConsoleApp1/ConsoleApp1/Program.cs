﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace ConsoleApp1
{
    class Program
    {
        private static double currentValue = 1000;
        static string userName, password, userNameConfirm, passwordConfirm;

        static void Main(string[] args)
        {
            Thread t3 = new Thread(CreateAccount);
            Thread t4 = new Thread(login);
            Thread t5 = new Thread(Unregistration);
            Thread t6 = new Thread(Deposit);            
            Thread t8 = new Thread(BalanceCheck);
            Thread t9 = new Thread(MoneyTransfer);
            Thread t10 = new Thread(AccountDetailsUpdate);
            Thread t11 = new Thread(SendMessages);
            Thread t12 = new Thread(DeactivateAccount);
            Thread t13 = new Thread(AccountInterest);
            Thread t14 = new Thread(BankCharges);

            //1.Start();
            //t2.Start();
           t3.Start();
            
        }

        private static void Withdrawls()
        {
            Console.WriteLine(" Enter the amount you want to withdraw ");
            double withrequest = Convert.ToDouble(Console.ReadLine());
            if(currentValue> withrequest)
            {
                Console.WriteLine(" You have successfully deducted " + withrequest+" Your balance is "+ (currentValue-withrequest));
                currentValue = currentValue - withrequest;
                Console.WriteLine("\n Press any key to exit from the system. ");
                Console.ReadLine();
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine(" Sorry You do not have sufficient funds to continoue ");
                Console.WriteLine(" \n Press any key to exit from the system. ");
                Console.ReadLine();
                Environment.Exit(0);
            }
        }

        private static void BalanceCheck()
        {
            Console.WriteLine("Your current balance is : " + currentValue);
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void MoneyTransfer()
        {
            Console.WriteLine("Enter the amount you want to transfer");
            double Transferrequest = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Thanks! You have successfully transfered " + Transferrequest);
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void AccountDetailsUpdate()
        {
            Console.WriteLine("Enter the new user name you want to update");
            userName = Console.ReadLine();
            Console.WriteLine("Enter the new password you want to update");
            password = Console.ReadLine();
            Console.WriteLine("Thanks! Your username and password has been updated successfully");
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void SendMessages()
        {
            Console.WriteLine("Please let me know the message you want to send");
            String message = Console.ReadLine();
            Console.WriteLine("Do you want to view the message you have send?");
            Console.Write("Do you want to login? Enter \"yes\" or \"no\" ");
            String allowed = Console.ReadLine();
            if (allowed.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Following message has been sent "+message + " \n Thanks");
               
            }
            else if (allowed.Equals("no", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Thanks! Welcome back soon");
            }
            else
            {
                Console.WriteLine("Visit again. Bye!");
            }
        }

        private static void DeactivateAccount()
        {
            Console.WriteLine("Thanks your account is successfully deactivated");
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void AccountInterest()
        {
            Console.WriteLine("Account Interest = "+(currentValue+currentValue*(2/100)));
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void BankCharges()
        {
            Console.WriteLine("Following is the banking charges.");
            Console.WriteLine("Monthly account charges - 0.00 \n Charges for exceeding authorised overdraft limits - 1% Excess amount \n Transfer Redirection charges - 2% \n Thanks for your inquery. Come back soon");
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void Deposit()
        {
            Console.WriteLine("Enter the amount you need to deposit ");
            double Depprequest = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(" Thank you! \n Your deposite is successfully Updated. \n Your new account balance is : " +(currentValue+Depprequest)+ " \n \n Press any key to exit from the system.");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void Unregistration()
        {
            Console.WriteLine("Thank you! You have successfully unregister");
            String userName = "";
            String password = "";
            Console.WriteLine("\n Press any key to exit from the system. ");
            Console.ReadLine();
            Environment.Exit(0);
        }

        private static void login()
        {
            Console.Write("Enter Username: ");
            userNameConfirm = Console.ReadLine();
            Console.Write("Enter Password:");
            passwordConfirm = Console.ReadLine();
            if (string.IsNullOrEmpty(userNameConfirm) || string.IsNullOrEmpty(passwordConfirm))
            {
                Console.WriteLine("Please enter both username and password");
                login();
            }
            if (userName.Equals(userNameConfirm, StringComparison.InvariantCultureIgnoreCase) && password.Equals(passwordConfirm, StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("You have successfully login. \n Please enter a value of the function that you want to perform\n 1.Deposit \n 2.AccountDetailsUpdate \n 3.MoneyTransfer \n 4.BalanceCheck \n 5.Withdrawls \n 6.Unregistration \n 7.DeactivateAccount \n 8.BankCharges \n");
                String switching = Console.ReadLine();
                switch (switching)
                {
                    case "1":
                        Deposit();
                        break;
                    case "2":
                        AccountDetailsUpdate();
                        break;
                    case "3":
                        MoneyTransfer();
                        break;
                    case "4":
                        BalanceCheck();
                        break;
                    case "5":
                        //Withdrawls();
                        Withdrawls();
                        break;
                    case "6":
                        Unregistration();
                        break;
                    case "7":
                        DeactivateAccount();
                        break;
                    case "8":
                        BankCharges();
                        break;

                }
            }
            else if (string.IsNullOrEmpty(password))
            {
                Console.WriteLine("Password can't empty");
                while (string.IsNullOrEmpty(password))
                {
                    Console.Write("Enter Password:");
                    password = Console.ReadLine();
                }
            }
            Console.Write("You have successfully Registered.");
            Console.Write("Do you want to login? Enter \"yes\" or \"no\" ");
            String allowed = Console.ReadLine();
            if (allowed.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
            {
                login();
            }
            else if (allowed.Equals("no", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Thanks for joining us. See you soon.");
            }
            else
            {
                Console.WriteLine("Visit again. Bye!");
            }
            Console.ReadLine();
            Console.WriteLine("You have successfully login");

        }

        public static void CreateAccount()
        {
            Console.Write("Enter Username: ");
            userName = Console.ReadLine();
            Console.Write("Enter Password:");
            password = Console.ReadLine();
            if (string.IsNullOrEmpty(userName))
            {
                Console.WriteLine("User Name is empty");
                CreateAccount();
            }
            else if (string.IsNullOrEmpty(password))
            {
                Console.WriteLine("Password can't empty");
                while (string.IsNullOrEmpty(password))
                {
                    Console.Write("Enter Password:");
                    password = Console.ReadLine();
                }
            }
            Console.Write("You have successfully Registered.");
            Console.Write("Do you want to login?Enter \"yes\" or \"no\" ");
            String allowed = Console.ReadLine();
            if (allowed.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
            {
                login();
            }
            else if (allowed.Equals("no", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Thanks for joining us. See you soon.");
            }
            else
            {
                Console.WriteLine("Visit again.Bye!");
            }
            Console.ReadLine();
        }

 

    }
}

