﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace cb005454_cna
{
    class Program
    {
        private static int currentValue = 1000;
        static string userName, password,userNameConfirm,passwordConfirm;

        static void Main(string[] args)
        {
            
            Thread t1 = new Thread(Job1);
            Thread t2 = new Thread(Job2);
            Thread t3 = new Thread(CreateAccount);
            Thread t4 = new Thread(login);
            Thread t5 = new Thread(Unregistration);
            Thread t6 = new Thread(Deposit);
            Thread t7 = new Thread(Withdrawls);
            Thread t8 = new Thread(BalanceCheck);
            Thread t9 = new Thread(MoneyTransfer);
            Thread t10 = new Thread(AccountDetailsUpdate);
            Thread t11 = new Thread(SendMessages);
            Thread t12 = new Thread(DeactivateAccount);
            Thread t13 = new Thread(AccountInterest);
            Thread t14 = new Thread(BankCharges);

           //1.Start();
          //  t2.Start();
            t3.Start();
            t7.Start();
            
            
        }

        private static void Withdrawls()
        {
            //Console.WriteLine(currentValue);

        }

        private static void BalanceCheck()
        {
            throw new NotImplementedException();
        }

        private static void MoneyTransfer()
        {
            throw new NotImplementedException();
        }

        private static void AccountDetailsUpdate()
        {
            throw new NotImplementedException();
        }

        private static void SendMessages()
        {
            throw new NotImplementedException();
        }

        private static void DeactivateAccount()
        {
            throw new NotImplementedException();
        }

        private static void AccountInterest()
        {
            throw new NotImplementedException();
        }

        private static void BankCharges()
        {
            throw new NotImplementedException();
        }

        private static void Deposit()
        {
            throw new NotImplementedException();
        }

        private static void Unregistration()
        {
            throw new NotImplementedException();
        }

        private static void login()
        {
            Console.Write("Enter Username: ");
            userNameConfirm = Console.ReadLine();
            Console.Write("Enter Password:");
            passwordConfirm = Console.ReadLine();
            if (string.IsNullOrEmpty(userNameConfirm)|| string.IsNullOrEmpty(passwordConfirm))
            {
                Console.WriteLine("Please enter both username and password");
                login();
            }
            if (userName.Equals(userNameConfirm, StringComparison.InvariantCultureIgnoreCase)&& password.Equals(passwordConfirm, StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("You have successfully login. \n Please enter a value of the function that you want to perform\n 1.Deposit \n 2.AccountDetailsUpdate \n 3.MoneyTransfer \n 4.BalanceCheck \n 5.Withdrawls \n 6.Unregistration \n 7.DeactivateAccount \n 8.BankCharges \n");
                String switching = Console.ReadLine();
                switch (switching)
                {
                    case "1":
                        Deposit();
                        break;
                    case "2":
                        SendMessages();
                        break;
                    case "3":
                        AccountDetailsUpdate();
                        break;
                    case "4":
                        MoneyTransfer();
                        break;
                    case "5":
                        BalanceCheck();
                        break;
                    case "6":
                        Withdrawls();
                        break;
                    case "7":
                        Unregistration();
                        break;
                    case "8":
                        DeactivateAccount();
                        break;
                    case "9":
                        BankCharges();
                        break;
                }
                        
                
                
                
                
                
               
                
                
            }
            else if (string.IsNullOrEmpty(password))
            {
                Console.WriteLine("Password can't empty");
                while (string.IsNullOrEmpty(password))
                {
                    Console.Write("Enter Password:");
                    password = Console.ReadLine();
                }
            }
            Console.Write("You have successfully Registered.");
            Console.Write("Do you want to login?Enter \"yes\" or \"no\" ");
            String allowed = Console.ReadLine();
            if (allowed.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
            {
                login();
            }
            else if (allowed.Equals("no", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Thanks for joining us. See you soon.");
            }
            else
            {
                Console.WriteLine("Visit again. Bye!");
            }
            Console.ReadLine();

            Console.WriteLine("You have successfully login");
               
        }

        public static void CreateAccount()
        {
            Console.Write("Enter Username: ");
            userName = Console.ReadLine();
            Console.Write("Enter Password:");
            password = Console.ReadLine();
            if (string.IsNullOrEmpty(userName))
            {
                Console.WriteLine("User Name is empty");
                CreateAccount();
            }
            else if (string.IsNullOrEmpty(password))
            {
                Console.WriteLine("Password can't empty");
                while (string.IsNullOrEmpty(password))
                {
                    Console.Write("Enter Password:");
                    password = Console.ReadLine();
                }
            }
            Console.Write("You have successfully Registered.");
            Console.Write("Do you want to login?Enter \"yes\" or \"no\" ");
            String allowed = Console.ReadLine();
            if (allowed.Equals("yes", StringComparison.InvariantCultureIgnoreCase)){
                login();
            }
            else if (allowed.Equals("no", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Thanks for joining us. See you soon.");
            }
            else
            {
                Console.WriteLine("Visit again. Bye!");
            }
            Console.ReadLine();
        }

        public static void Job1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Job 1 - " + i);
                Thread.Sleep(1000);
            }
        }

        public static void Job2()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Job 2 - " + i);
                Thread.Sleep(1000);
            }
        }
    }
}