
public class productionManager extends capacityPlanning {
	
	complitionDate complitionDate =  new complitionDate() {
		
		@Override
		public void viewComplitionDate() {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void scheduleApplicationDate() {
			// TODO Auto-generated method stub
			
		}
	};
	
	
	capacityPlanning cp = new capacityPlanning();
	boolean rejectionNotice  =  cp.createRejectionNotice();

}



