
public class Employee implements numberOfOrders, freeEmployee, scheduleEmployeee, allocatedEmployees {
	int numberofPermenentEmployees;
	int numberofContractors;
	int currentOrders;
	int totalOrdermanhours, freeemployeecount, totalEmployees, allocatedEmployees;
	double freetime;

	public int getTotalOrdermanhours() {
		return totalOrdermanhours;
	}

	public void setTotalOrdermanhours(int totalOrdermanhours) {
		this.totalOrdermanhours = totalOrdermanhours;
	}

	public int getCurrentOrders() {
		return currentOrders;
	}

	public void setCurrentOrders(int currentOrders) {
		this.currentOrders = currentOrders;
	}

	public int getNumberofPermenentEmployees() {
		return numberofPermenentEmployees;
	}

	public void setNumberofPermenentEmployees(int numberofPermenentEmployees) {
		this.numberofPermenentEmployees = numberofPermenentEmployees;
	}

	public int getNumberofContractors() {
		return numberofContractors;
	}

	public void setNumberofContractors(int numberofContractors) {
		this.numberofContractors = numberofContractors;
	}

	@Override
	public double getNumberOfResources() {
		return numberofPermenentEmployees + numberofContractors;
	}

	public double getMaximumManHours() {
		/*
		 * This will return the maximum amount of man hours per day Assumption - both
		 * contractors and permanent employees have equal time slots
		 */
		return (numberofContractors + numberofPermenentEmployees) * 7.5;

	}

	@Override
	public void viewNoOfOrders() {
		System.out.println("Number of orders for current week is :" + currentOrders);
	}

	@Override
	public void viewFreeEmployees() {
		if (currentOrders > 0) {
			if (totalOrdermanhours < (numberofContractors + numberofPermenentEmployees) * 7.5) {
				freetime = totalOrdermanhours - ((numberofContractors + numberofPermenentEmployees) * 7.5);
			}
		}
		freeemployeecount = (int) (freetime / 7.5);

	}

	public int getFreemployees() {
		return freeemployeecount;
	}

	@Override
	public void allocatedEmployees() {
		if (freetime < 0) {
			System.out.println("All employees are fully allocated");
		} else {
			totalEmployees = numberofPermenentEmployees + numberofContractors;
			allocatedEmployees = totalEmployees - freeemployeecount;

		}

	}

	@Override
	public void viewSchedule() {
		System.out.println("This will provide an overview of shedule of the allocated resources");

	}

}
