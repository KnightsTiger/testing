
public interface complitionDate {
	public void scheduleApplicationDate();
	public void viewComplitionDate();
}
