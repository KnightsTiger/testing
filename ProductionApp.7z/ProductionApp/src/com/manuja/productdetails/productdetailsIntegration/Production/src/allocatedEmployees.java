
public interface allocatedEmployees {

	double getNumberOfResources();
}
