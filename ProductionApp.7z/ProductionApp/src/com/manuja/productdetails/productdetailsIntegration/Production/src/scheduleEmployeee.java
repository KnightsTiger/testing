
public interface scheduleEmployeee {
public void allocatedEmployees();
public void viewSchedule();
}
